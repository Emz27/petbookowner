function onload(){
     $(document).ready(function(){
              $("#show").click(function(){
                  $("[href]").show(500);
              });
          });
}
