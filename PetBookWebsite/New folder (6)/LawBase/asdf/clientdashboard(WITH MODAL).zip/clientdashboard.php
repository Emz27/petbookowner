<html>
<head>
     <!-- Required meta tags -->
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!-- LINK BOOTSTRAP -->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
     <!-- LINK CSS -->
     <link href="css/clientdashboard.css" rel="stylesheet">
     <!-- FONTS -->
     <link href="https://fonts.googleapis.com/css?family=Bitter" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Merriweather" rel="stylesheet">
     <title>Client's Dashboard</title>
     <link rel="icon" type="image/png" href="images/lawbase.png">
</head>
<body>
     <header>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
                <div class="container">
                <button class="navbar-toggler" data-toggle="collapse" data-target="#collapse_target">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapse_target">
                    <ul class="header-nav navbar-nav mr-auto">
                         <a href="index"><img src="images/lawbase2.png" alt="Logo" style="width:50px; margin-left: 8px;"></a>
                    </ul>
                    <ul class="header-nav navbar-nav">
                        <li class="nav-item"><a class="nav-link" href="database">Database</a></li>
                        <li class="nav-item"><a class="nav-link" href="offer">For Lawyers</a></li>
                        <li class="nav-item"><a class="nav-link" href="about">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="list">List</a></li>
                        <li class="nav-item"><a class="nav-link" href="faq">Q&A</a></li>
                        <?PHP
                        if(isset($_COOKIE['SNID'])){
                            echo '
                            <li class="nav-item"><a class="nav-link" id="logout" href="logout">Logout</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
            </nav>
     </header>
<body>

          <div id="content" class="container">
               <div class="row">
                    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                    </div>

                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                         <img class="rounded" id="thumbnail"/><br>
                               <button type="button" id="button_to_upload" class="btn btn-dark" id="btn" data-toggle="modal" data-target="#upload">Upload Image</button>
                               <!-- Modal -->
                                        <div id="upload" class="modal fade" role="dialog">
                                          <div class="modal-dialog modal-sm">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                              </div>
                                              <div class="modal-body">
                                               <img id="img" class="container_upload" src="images/qmark.png"></img>
                                                   <div class="btn-group">
                                                        <form action="imageupload.php" method="POST" enctype="multipart/form-data">
                                                            <input id="file" type="file" name="image" class="btn btn-primary btn-block">
                                                            <button type="submit" id="submit" name="submit" class="btn btn-success btn-block">Upload</button>
                                                        </form>
                                                 </div>
                                              </div>
                                            </div>

                                          </div>
                                        </div>
               <!-- CLIENTS NAME DITO MO HUHUGUTIN BATS
          =================================================
     ===================================================-->
                         <p id="clients_name">Name:</p>

                         <!-- CLIENTS QUESTIONS DITO MO HUHUGUTIN BATS
                    =================================================
               ===================================================-->

                    <div id="container_que" class="container">
                         <p id="question_number" >Question #1</p>
                          <button type="button" id="chatlog_" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#questions">Click here to view message conversation for this question</button>
                         <p id="question_content">SAMPLE QUESTION HERE!!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!
                         SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!
                    SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!
               SAMPLE QUESTION HERE!!SAMPLE QUESTION HERE!!</p>
               <hr>
                    </div>
                    <div class="row">
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    </div>

                     <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <!-- The Modal -->
                           <div class="modal fade" id="questions">
                             <div class="modal-dialog modal-md">
                               <div class="modal-content">

                                 <!-- Modal Header -->
                                 <div class="modal-header">
                         <!-- QUESTION # -->
                                   <h4 class="modal-title">Question #1</h4>
                                   <button type="button" class="close" data-dismiss="modal">&times;</button>
                                 </div>

                                 <!-- Modal body -->
                                 <div class="modal-body">

                         <!-- CHAT BOX (MESSENGER) -->
                                      <div class="chatbox">
                                          <div class="chatlogs">
                                               <div class="chat lawyer">
                                                    <div id="lawyer_photo" class="user-photo"></div>
                                                    <p id="lawyer_chat" class="chat-message">Hello! I'm the Lawyer</p>
                                               </div>

                                               <div class="chat client">
                                                    <div id="client_photo" class="user-photo"></div>
                                                    <p id="client_chat" class="chat-message">Hi! I'm the client</p>
                                               </div>

                                               <div class="chat lawyer">
                                                    <div id="lawyer_photo" class="user-photo"></div>
                                                    <p id="lawyer_chat" class="chat-message">Sample Text HereSample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!!</p>
                                               </div>

                                               <div class="chat lawyer">
                                                    <div id="lawyer_photo" class="user-photo"></div>
                                                    <p id="lawyer_chat" class="chat-message">Hello!</p>
                                               </div>

                                               <div class="chat client">
                                                    <div id="client_photo" class="user-photo"></div>
                                                    <p id="client_chat" class="chat-message">Hi!</p>
                                               </div>

                                               <div class="chat lawyer">
                                                    <div id="lawyer_photo" class="user-photo"></div>
                                                    <p id="lawyer_chat" class="chat-message">Sample Text HereSample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!Sample Text Here!
                                                         Sample Text Here!Sample Text Here!!</p>
                                               </div>
                                          </div>

                                          <div class="chat-form">
                                               <textarea></textarea>
                                               <button id="submit_button" class="btn btn-info btn-lg">Send</button>
                                          </div>
                                     </div>
                                 </div>

                               </div>
                             </div>
                           </div>
                      </div>

                      <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                      </div>
                 </div>
                           <!--- END MODAL -->
          </div>

                    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                    </div>
               </div>
          </div>



          <!-- Optional JavaScript -->
         <!-- jQuery first, then Popper.js, then Bootstrap JS -->
         <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
         <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
         <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
</body>
</html>
