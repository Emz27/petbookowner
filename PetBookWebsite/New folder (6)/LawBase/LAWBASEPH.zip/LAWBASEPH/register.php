
<?php
include('classes/DB.php');
include_once('connection.php');
use PHPMailer\PHPMailer\PHPMailer;
include_once('PHPMailer/PHPMailer.php');


if(isset($_COOKIE['SNID']) && isset($_COOKIE['lawyerID'])){
    header('location: main');
}

if (isset($_POST['registerLawyer']))
{
    $firstname =  $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname =   $_POST['lastname'];
    $address =    $_POST['address'];
    $contact =    $_POST['contact'];
    $spec1 =      $_POST['spec1'];
    $spec2 =      $_POST['spec2'];
    $spec3 =      $_POST['spec3'];
    $username =   $_POST['username'];
    $password =   $_POST['password'];
    $email =      $_POST['email'];
    $pitch =      $_POST['pitch'];
    $roll =       $_POST['roll'];
    $firm =       $_POST['firm'];
    $status =     "unpaid";
    $admit =      $_POST['admit'];

    $token = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890!^*()[]";
    $token = str_shuffle($token);
    $hashedToken = substr($token, 0 , 10);

    $validRoll = substr($roll, 0, 1);

    if ( strpos($spec1 , 'NON') !== false AND strpos($spec2 , 'NON') !== false AND strpos($spec3 , 'NON') !== false) {
        echo '<script>(function(){
                alert(\'Please select at least 1 Specialization.\'); 
                return false;
                }
                )()</script>';
    } else if(strpos($admit, 'Admitted to the bar') !== false) {
        echo '<script>(function(){
            alert(\'Please select a year admitted to the bar.\'); 
            return false;
            }
            )()</script>';
    }else if(!preg_match('/^[1-7]+$/', $validRoll)){
        echo '<script>(function(){
                alert(\'Invalid Roll Number.\'); 
                return false;
                }
                )()</script>';
    } else {

        if(!DB::query('SELECT userName FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))){
            if(strlen($username) >= 8 && strlen($username) <= 32){
                if(preg_match('/[a-zA-Z0-9_]+/', $username)){
                    if(strlen($password) >= 8 && strlen($password) <= 32){
                        if(filter_var($email, FILTER_VALIDATE_EMAIL)){
                            if(!DB::query('SELECT userEmail FROM tblLawyer WHERE userEmail=:userEmail', array(':userEmail'=>$email))){
                                if(!DB::query('SELECT RollNo FROM tblLawyer WHERE RollNo=:RollNo', array(':RollNo'=>$roll))){
                                    
                                    DB::query('INSERT INTO tblLawyer VALUES (\'\', :userName, :userPassword, :userFirstname, :userMiddlename, :userLastname, :userAddress, :userEmail, :userContactNumber, :admittedToTheBar, :RollNo, :lawFirm, :pitch, :specialization1, :specialization2, :specialization3, :lawyerStatus, :isEmailVerified, :emailVerificationToken)', array(':userName'=>$username, ':userPassword'=>password_hash($password, PASSWORD_BCRYPT), ':userFirstname'=>$firstname, ':userMiddlename'=>$middlename, ':userLastname'=>$lastname, ':userAddress'=>$address, ':userEmail'=>$email, ':userContactNumber'=>$contact, ':admittedToTheBar'=>$admit, ':RollNo'=>$roll, 'lawFirm'=>$firm, ':pitch'=>$pitch, ':specialization1'=>$spec1, ':specialization2'=>$spec2, ':specialization3'=>$spec3, ':lawyerStatus'=>$status,  ':isEmailVerified'=>0,':emailVerificationToken'=>$hashedToken));
                
                                    $mail = new PHPMailer();
                                    $mail->setFrom('jjalcancia@gmail.com');
                                    $mail->addAddress($email, $firstname);
                                    $mail->Subject = "Lawbase account verification";
                                    $mail->isHTML(true);
                                    $mail->Body = "
                                        <h1>Please click the link below:</h1><br><br>

                                        <a href='http://www.oakstonecorp.com/newlawbase/emailconfirm.php?email=$email&token=$hashedToken'>Click here to verify!!!</a>
                                    ";

                                    if($mail->send()){
                                        echo '<script>(function(){
                                            alert(\'Registration Success!!!\');
                                        }
                                    )()</script>';
                                    }else{
                                        echo 'something went wrong!';
                                        }
                                   
                                }else{
                                    echo '<script>(function(){
                                        alert(\'Roll number already registered.\'); 
                                        return false;
                                    }
                                )()</script>'; 
                                }
                            }else{
                                echo '<script>(function(){
                                            alert(\'Email already registered.\'); 
                                            return false;
                                        }
                                    )()</script>';
                            }
                        }else{
                            echo '<script>(function(){
                                            alert(\'Invalid Email.\'); 
                                            return false;
                                        }
                                    )()</script>';
                        }
                    }else{
                        echo '<script>(function(){
                                    alert(\'Password must be 8 characters long.\'); 
                                    return false;
                                }
                            )()</script>';
                    }
                }else{
                    echo '<script>(function(){
                                alert(\'Username Email.\'); 
                                return false;
                            }
                        )()</script>';
                }
            }else{
                echo '<script>(function(){
                            alert(\'Username must be 8 characters long.\'); 
                            return false;
                        }
                    )()</script>';
            }
        }else{
            echo '<script>(function(){
                        alert(\'Username is already taken.\'); 
                        return false;
                    }
                    )()</script>';
        }
    }
}

else if (isset($_POST['lawyerLogin']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];

    if(DB::query('SELECT userName FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))){
        if(password_verify($password, DB::query('SELECT userPassword FROM tblLawyer WHERE userName=:userName',array(':userName'=>$username))[0]['userPassword'])){
            $isVerified = DB::query('SELECT isEmailVerified FROM tblLawyer WHERE userName=:userName', array('userName'=>$username))[0]['isEmailVerified'];
            if($isVerified == 1){
                $csstrong = True;
                $token = bin2hex(openssl_random_pseudo_bytes(64, $csstrong));
                $lawyerID = DB::query('SELECT lawyerID FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))[0]['lawyerID'];
                $specialization1 = DB::query('SELECT specialization1 FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))[0]['specialization1'];
                $specialization2 = DB::query('SELECT specialization2 FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))[0]['specialization2'];
                $specialization3 = DB::query('SELECT specialization3 FROM tblLawyer WHERE userName=:userName', array(':userName'=>$username))[0]['specialization3'];
                DB::query('INSERT INTO tblTokens VALUES (\'\', :token, :lawyerID)', array(':token'=>sha1($token), ':lawyerID'=>$lawyerID));
    
                setcookie("SNID", $token, time() + 60 * 60 * 24 * 7, '/', NULL, NULL, TRUE);
                setcookie("specialization1", $specialization1, time() + 60 * 60 * 24 * 7, '/', NULL, NULL, TRUE);
                setcookie("specialization2", $specialization2, time() + 60 * 60 * 24 * 7, '/', NULL, NULL, TRUE);
                setcookie("specialization3", $specialization3, time() + 60 * 60 * 24 * 7, '/', NULL, NULL, TRUE);
                echo '<script>(function(){
                        alert(\'Logged in.\'); 
                        window.location.href="auth";
                    }
                    )()</script>';
            }else{
                echo '<script>(function(){
                    alert(\'Account not verified. Please activate your account using the email that was sent to your email.\'); 
                    return false;
                }
                )()</script>';
            }
        }else{
            echo '<script>(function(){
                    alert(\'Invalid password.\'); 
                    return false;
                }
                )()</script>';
        }
    }else{
        echo '<script>(function(){
                alert(\'User not registered.\'); 
                return false;
            }
            )()</script>';
    }
}
?>

<html>
<head>

    <meta charset="utf-8">

    <link href="style.css" rel="stylesheet">
    <link href="node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>LawBase</title>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark sticky-top">
    <div class="container">
        <button class="navbar-toggler" data-toggle="collapse" data-target="#collapse_target">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="collapse_target">
            <ul class="header-nav navbar-nav mr-auto">
            </ul>

            <ul class="header-nav navbar-nav">
                <li class="nav-item"><a class="nav-link" href="#">Database</a></li>
                <li class="nav-item"><a class="nav-link active" href="register">For Lawyers</a></li>
                <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                <li class="nav-item"><a class="nav-link" href="list">List</a></li>
            </ul>
        </div>
    </div>
</nav>





<section class="p-5 regSection">
    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8 p-5 regForm">
                <table id="registerTable">
                    <tr>
                        <td>
                            <form action='<?PHP $_PHP_SELF?>' method="post">
                                <h1 class="title pb-3">Lawyer Registration</h1>

                                <input type="name" name="username" class="form-control" placeholder="Username" required autofocus=""></br>

                                <input type="password" name="password" class="form-control" placeholder="Password" required></br>


                                <input type="fistname" name="firstname" class="form-control" placeholder="Firstname" required></br>

                                <input type="name" name="middlename" class="form-control" placeholder="Middlename(Optional)"></br>

                                <input type="name" name="lastname" class="form-control" placeholder="Lastname" required></br>

                                <input type="name" name="address" class="form-control" placeholder="Address" required></br>

                                <input type="name" name="contact" class="form-control" placeholder="Contact Number" required></br>

                                <input type="number" name="roll"  class="form-control" placeholder="Roll no" min="10000" max="99999" required></br>

                                <select id="admit" name="admit" class="form-control" placeholder="Admitted to the bar" required>
                                    <option>Admitted to the bar</option>
                                    <?PHP
                                    for($x = 1960; $x <= 2020; $x++){
                                        echo '<option>'.$x.'</option>';
                                    }
                                    ?>
                                </select>></br>

                                <input type="name" name="firm" class="form-control" placeholder="Law firm (if any)"></br>

                                <input type="text" name="email" class="form-control" placeholder="Email" required></br>

                                <textarea class="form-control" rows="5" type="name" name="pitch" placeholder="Make a pitch for yourself" required></textarea></br>

                                <select name = "spec1" class="form-control" onchange="checkUnique(this.id);" required>
                                    <option value="NON" selected>Specialization</option>
                                    <?PHP
                                    $query = "SELECT * FROM tbl_practices;";
                                    $result = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_assoc($result))
                                        {
                                            echo '<option value= "'.$row['pracCode'].'" >'.$row['pracCode'] . " - " . $row['pracName'].'</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                </br>
                                <select name = "spec2" class="form-control" onchange="checkUnique(this.id);" required>
                                    <option value="NON" selected>Specialization</option>
                                    <?PHP
                                    $query = "SELECT * FROM tbl_practices;";
                                    $result = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_assoc($result))
                                        {
                                            echo '<option value= "'.$row['pracCode'].'" >'.$row['pracCode'] . " - " . $row['pracName'].'</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                </br>
                                <select name = "spec3"  class="form-control" onchange="checkUnique(this.id);" required>
                                    <option value="NON" selected>Specialization</option>
                                    <?PHP
                                    $query = "SELECT * FROM tbl_practices;";
                                    $result = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_assoc($result))
                                        {
                                            echo '<option value= "'.$row['pracCode'].'" >'.$row['pracCode'] . " - " . $row['pracName'].'</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                </br>

                                <label class="checkbox-inline pb-3" style="color: white"><input type="checkbox" value="" required>I agree to the <a href="#">Terms and agreement</a>.</label><br>

                                <button type='submit' value = 'lawyer' name='registerLawyer' class='btn btn-lg btn-block'>Register</button>
                            </form>
                        </td>
                        <td>

                            <form action='<?PHP $_PHP_SELF ?>' method="post">

                                <h1 class="pb-3 title">Lawyer <br> Login</h1>

                                <input type="name" name="username" class="form-control" placeholder="Username" required autofocus=""></br>

                                <input type="password" name="password" class="form-control" placeholder="Password" required></br>

                                <button type='submit' value = 'lawyerLogin' name='lawyerLogin' class='btn-default btn-lg btn-block'>Login</button>
                            </form>

                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
</section>

<script src="node_modules/jquery/dist/jquery.min.js"></script>
<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>