function taskButtons(subCategory, category){
    window.location.href = "post?subCategory="+subCategory+"&category="+category;
}